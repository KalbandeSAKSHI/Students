﻿namespace Students.Controllers
{
    public class Interface
    {
    }
}
