﻿namespace Students.Controllers
{
    public class Student_details
    {
    }
}
